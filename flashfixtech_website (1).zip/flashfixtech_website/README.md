# FlashfixTech — Colorful Web Design Template

This repository contains a simple, colorful, mobile-friendly static website you can host for free on GitHub Pages.

## What is included
- `index.html`, `about.html`, `services.html`, `portfolio.html`, `testimonials.html`, `contact.html`
- `assets/css/style.css` — main styling
- `assets/js/main.js` — lightweight front-end animation
- `README.md` — this file

## How to publish on GitHub Pages
1. Create a new GitHub repository (name it `flashfixtech` or something you prefer).
2. Upload all files (or push them with git).
3. In repository Settings → Pages, choose the `main` branch and `/ (root)` folder. Save.
4. Your site will be available at `https://<username>.github.io/<repo>` (or at `https://<username>.github.io` for repositories named `<username>.github.io`).

## Notes
- Replace the portfolio sample tiles with screenshots of your real projects before sharing publicly.
- The contact form is a demo and does not send messages — connect to Formspree, Netlify Forms, or your own backend for form handling.
- Update contact details in the footer if needed.

Contact: donaldkipkorir266@gmail.com
