// Small interactive touches
document.addEventListener('DOMContentLoaded', function(){
  // Simple fade-in for elements
  const els = document.querySelectorAll('.container > section, .card, .tile, blockquote');
  els.forEach((el,i)=> {
    el.style.opacity = 0;
    el.style.transform = 'translateY(12px)';
    setTimeout(()=> {
      el.style.transition = 'opacity 500ms ease, transform 500ms ease';
      el.style.opacity = 1;
      el.style.transform = 'none';
    }, 120 * i);
  });
});
